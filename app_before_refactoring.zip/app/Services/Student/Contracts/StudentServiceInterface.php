<?php

namespace App\Services\Student\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface StudentServiceInterface
 */
interface StudentServiceInterface extends BaseCrudServiceInterface
{

}