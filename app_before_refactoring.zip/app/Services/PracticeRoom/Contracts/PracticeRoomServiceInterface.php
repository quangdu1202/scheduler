<?php

namespace App\Services\PracticeRoom\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface PracticeRoomServiceInterface
 */
interface PracticeRoomServiceInterface extends BaseCrudServiceInterface
{

}