<?php

namespace App\Services\Registration\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface RegistrationServiceInterface
 */
interface RegistrationServiceInterface extends BaseCrudServiceInterface
{

}