<?php

namespace App\Services\PracticeClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface PracticeClassServiceInterface
 */
interface PracticeClassServiceInterface extends BaseCrudServiceInterface
{

}