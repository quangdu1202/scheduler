<?php

namespace App\Services\OriginalClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface OriginalClassServiceInterface
 */
interface OriginalClassServiceInterface extends BaseCrudServiceInterface
{

}