<?php

namespace App\Services\MarkType\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface MarkTypeServiceInterface
 */
interface MarkTypeServiceInterface extends BaseCrudServiceInterface
{

}