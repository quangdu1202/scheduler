<?php

namespace App\Services\ModuleClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface ModuleClassServiceInterface
 */
interface ModuleClassServiceInterface extends BaseCrudServiceInterface
{

}