<?php

namespace App\Services\StudentModuleClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface StudentModuleClassServiceInterface
 */
interface StudentModuleClassServiceInterface extends BaseCrudServiceInterface
{

}