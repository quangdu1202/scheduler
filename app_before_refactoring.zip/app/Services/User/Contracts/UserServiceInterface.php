<?php

namespace App\Services\User\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface UserServiceInterface
 */
interface UserServiceInterface extends BaseCrudServiceInterface
{

}