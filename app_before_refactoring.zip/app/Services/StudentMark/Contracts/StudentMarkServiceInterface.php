<?php

namespace App\Services\StudentMark\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface StudentMarkServiceInterface
 */
interface StudentMarkServiceInterface extends BaseCrudServiceInterface
{

}