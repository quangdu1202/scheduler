<?php

namespace App\Services\Teacher\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface TeacherServiceInterface
 */
interface TeacherServiceInterface extends BaseCrudServiceInterface
{

}