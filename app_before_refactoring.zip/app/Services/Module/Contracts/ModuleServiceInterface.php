<?php

namespace App\Services\Module\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Services\Contracts\BaseCrudServiceInterface;

/**
 * Interface ModuleServiceInterface
 */
interface ModuleServiceInterface extends BaseCrudServiceInterface
{

}