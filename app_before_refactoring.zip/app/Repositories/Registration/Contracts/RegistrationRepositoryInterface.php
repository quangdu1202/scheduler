<?php

namespace App\Repositories\Registration\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface RegistrationRepositoryInterface
 */
interface RegistrationRepositoryInterface extends BaseRepositoryInterface
{

}