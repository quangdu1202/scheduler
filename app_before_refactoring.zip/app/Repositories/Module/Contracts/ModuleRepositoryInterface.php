<?php

namespace App\Repositories\Module\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface ModuleRepositoryInterface
 */
interface ModuleRepositoryInterface extends BaseRepositoryInterface
{

}