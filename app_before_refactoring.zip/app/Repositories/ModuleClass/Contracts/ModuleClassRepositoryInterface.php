<?php

namespace App\Repositories\ModuleClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface ModuleClassRepositoryInterface
 */
interface ModuleClassRepositoryInterface extends BaseRepositoryInterface
{

}