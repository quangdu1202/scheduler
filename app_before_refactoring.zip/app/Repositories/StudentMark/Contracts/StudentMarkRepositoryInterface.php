<?php

namespace App\Repositories\StudentMark\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface StudentMarkRepositoryInterface
 */
interface StudentMarkRepositoryInterface extends BaseRepositoryInterface
{

}