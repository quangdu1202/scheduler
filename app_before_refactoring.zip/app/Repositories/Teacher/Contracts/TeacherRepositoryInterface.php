<?php

namespace App\Repositories\Teacher\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface TeacherRepositoryInterface
 */
interface TeacherRepositoryInterface extends BaseRepositoryInterface
{

}