<?php

namespace App\Repositories\MarkType\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface MarkTypeRepositoryInterface
 */
interface MarkTypeRepositoryInterface extends BaseRepositoryInterface
{

}