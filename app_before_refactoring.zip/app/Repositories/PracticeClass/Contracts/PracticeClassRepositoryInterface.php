<?php

namespace App\Repositories\PracticeClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface PracticeClassRepositoryInterface
 */
interface PracticeClassRepositoryInterface extends BaseRepositoryInterface
{

}