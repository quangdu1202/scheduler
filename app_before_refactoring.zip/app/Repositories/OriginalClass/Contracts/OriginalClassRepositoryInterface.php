<?php

namespace App\Repositories\OriginalClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface OriginalClassRepositoryInterface
 */
interface OriginalClassRepositoryInterface extends BaseRepositoryInterface
{

}