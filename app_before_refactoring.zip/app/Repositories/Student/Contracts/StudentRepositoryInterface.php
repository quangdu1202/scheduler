<?php

namespace App\Repositories\Student\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface StudentRepositoryInterface
 */
interface StudentRepositoryInterface extends BaseRepositoryInterface
{

}