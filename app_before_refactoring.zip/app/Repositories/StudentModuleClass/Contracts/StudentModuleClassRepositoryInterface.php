<?php

namespace App\Repositories\StudentModuleClass\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface StudentModuleClassRepositoryInterface
 */
interface StudentModuleClassRepositoryInterface extends BaseRepositoryInterface
{

}