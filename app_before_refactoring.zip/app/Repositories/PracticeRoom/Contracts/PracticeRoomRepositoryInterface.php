<?php

namespace App\Repositories\PracticeRoom\Contracts;

use Adobrovolsky97\LaravelRepositoryServicePattern\Repositories\Contracts\BaseRepositoryInterface;

/**
 * Interface PracticeRoomRepositoryInterface
 */
interface PracticeRoomRepositoryInterface extends BaseRepositoryInterface
{

}